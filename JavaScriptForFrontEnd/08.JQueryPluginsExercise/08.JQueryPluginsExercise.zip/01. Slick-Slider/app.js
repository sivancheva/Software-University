$(".cats").slick({
    dots: true,
    arrows: true,

    slidesToShow: 3,
    slidesToScroll: 3,

});