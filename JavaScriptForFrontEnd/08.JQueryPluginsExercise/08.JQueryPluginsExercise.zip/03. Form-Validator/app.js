$.validate({
});
$( "#italic-btn" ).click(function() {
    $("#userInput").css("font-style", "italic");
});

$( "#bold-btn" ).click(function() {
    $("#userInput").css("font-style", "bold");
});