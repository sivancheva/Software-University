$('#producedOn').datetimepicker({

});