﻿using System;
using System.Collections.Generic;
using System.Text;


public class CreateConstructors
{
    static void Main(string[] args)
    {
        
     
    }
}
