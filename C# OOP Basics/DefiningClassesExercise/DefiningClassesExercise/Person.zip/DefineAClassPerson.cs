﻿using System;

public class DefineAClassPerson
{
    static void Main(string[] args)
    {
        Person person = new Person();
        person.Name = "Pe6o";
        person.Age = 25;
    }
}
