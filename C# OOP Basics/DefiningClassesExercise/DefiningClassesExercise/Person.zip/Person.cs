﻿using System;
using System.Collections.Generic;
using System.Text;


public class Person
{
    private string name;
    private int age;


    public string Name
    {
        get { return Name; }
        set { Name = value; }
    }

    public int Age
    {
        get { return age; }
        set { age = value; }
    }
}
