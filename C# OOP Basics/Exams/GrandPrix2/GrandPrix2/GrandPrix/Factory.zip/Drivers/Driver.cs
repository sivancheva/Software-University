﻿using System;
using System.Collections.Generic;
using System.Text;


public abstract class Driver
{
    
    private string Name { get; }
    private double TotalTime { get; }
    private Car Car { get; set; }
    private double fuelConsumption;
    private double speed;
    
    protected Driver(string name, Car car)
    {
        this.Name = name;
        this.Car = car;
    }


    public double FuelConsumption
    {
        get { return fuelConsumption; }
        protected set { fuelConsumption = value; }
    }

    public double Speed
    {
        get { return speed; }
        protected set
        {
            speed = (this.Car.Hp + this.Car.Tyre.Degradation) / this.Car.FuelAmount;
        }
    }
}

