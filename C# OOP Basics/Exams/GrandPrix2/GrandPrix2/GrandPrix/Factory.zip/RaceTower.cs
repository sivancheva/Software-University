﻿using System;
using System.Collections.Generic;
using System.Text;


public class RaceTower
{
    public void SetTrackInfo(int lapsNumber, int trackLength)
    {
        //TODO: Add some logic here …
    }
    public void RegisterDriver(List<string> commandArgs)
    {
        //TODO: Add some logic here …
    }

    public void DriverBoxes(List<string> commandArgs)
    {
        //TODO: Add some logic here …
    }

    public string CompleteLaps(List<string> commandArgs)
    {
        //TODO: Add some logic here …
        return "";
    }

    public string GetLeaderboard()
    {
        //TODO: Add some logic here …
        return "";
    }

    public void ChangeWeather(List<string> commandArgs)
    {
        //TODO: Add some logic here …
    }

}

